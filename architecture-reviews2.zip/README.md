# architecture-reviews
A repository of reviews and analysis of the architecture of open source systems.

[1. VSCode](vscode/index.md)

[2. Bitcoin](bitcoin/index.md)

[3. IPFS](ipfs/index.md)

[4. Blender](blender/index.md)

[5. ElasticSearch](elasticsearch/index.md)

[6. OpenEdx](openedx/index.md)

[7. Linux](linux/index.md)
