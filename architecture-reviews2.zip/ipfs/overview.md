# IPFS - Overview

## Description

//ToDo: Provide an overall description of the system and mainfunctional characteristics:  what is the purpose of the system, whouses the system, what type of users does the system have and whatcan each type of user do with the system.

## Visualization

//ToDo: Using Structurizr model the architectural structure ofthe system, and generate a Landscape/Context diagram and one ormore Container diagrams.  You must include all types of users, and allexternal services integrated.

![alt text](assets/default.png "Image Example")

## Quality Attrbiutes

//ToDo: Describe the 3 principal QAs for the project,based on your understanding of the system.  Provide 1 relevant QAscenario for each.
